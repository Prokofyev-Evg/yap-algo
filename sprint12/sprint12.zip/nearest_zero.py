# ID Правильного решения 52069567
import sys
from math import inf


def main():
    input()
    street = list([int(x) for x in sys.stdin.readline().rstrip().split()])
    distance = calc_distance(street)
    print(' '.join(map(str, distance)))


def calc_distance(street):
    length = len(street)
    distance = [inf] * length
    d1 = length
    d2 = length
    for i in range(length):
        d1 = 0 if street[i] == 0 else d1 + 1
        d2 = 0 if street[length - 1 - i] == 0 else d2 + 1
        distance[i] = min(d1, distance[i])
        distance[length - 1 - i] = min(d2, distance[length - 1 - i])
    return distance


if __name__ == '__main__':
    main()
